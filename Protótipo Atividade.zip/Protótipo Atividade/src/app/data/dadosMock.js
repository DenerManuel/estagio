export const dadosCategoriasMock = [
  {
    titulo: 'Animals',
    itens: [
      { nome: 'chicken1', imagem: 'chicken.svg' },
      { nome: 'chicken2', imagem: 'chicken.svg' },
      { nome: 'chicken3', imagem: 'chicken.svg' }
    ]
  },
  {
    titulo: 'Comida',
    itens: [
      { nome: 'comida1', imagem: 'food.svg' },
      { nome: 'comida2', imagem: 'food.svg' },
      { nome: 'comida3', imagem: 'food.svg' }
    ]
  }
];