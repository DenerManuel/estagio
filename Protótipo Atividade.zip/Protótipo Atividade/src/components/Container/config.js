// Configurações padrão compartilhadas
export const ConfigContainer = {
  DEFAULTS: {
    largura: 100,
    altura: 100,
    corFundo: null,
    borda: 0,
    corBorda: 0x000000, // Preto
    arredondamento: 0
  }
};